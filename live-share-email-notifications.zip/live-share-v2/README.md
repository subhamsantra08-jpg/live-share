# Live Share — HTTPS + safety features edition

Live Share is a consent-based, two-device sharing prototype. It supports private location sharing, optional screen sharing, approved-device access, encrypted chat, SOS alerts, and a Caddy HTTPS deployment.

## New in this edition

- **QR connection:** the sharing phone displays a QR code that opens the viewer page with the session code filled in. The password is deliberately NOT embedded in the QR code; enter it separately on the viewer phone.
- **Live map, movement and speed:** when the sharer chooses location sharing, the viewer sees the latest position, a breadcrumb trail, GPS speed (when the phone/browser supplies it), and heading. Map tiles are provided by OpenStreetMap.
- **SOS alert:** either participant can send an SOS alert to the other participant. It is an in-app alert only; it does not contact emergency services or automatically send location. The participant can still stop sharing at any time.
- **Private chat:** chat messages are encrypted in the browser with AES-256-GCM using the session key derived from the session password and code. The server relays ciphertext and does not store chat history.
- **Automatic expiry:** sessions expire after 15 minutes without activity or at 4 hours maximum, whichever comes first. Server restart also ends all in-memory sessions.
- **Stronger password verification:** session passwords must be at least 12 characters and include letters and numbers. The server stores a salted scrypt verifier and compares it in constant time. Join attempts are limited to 10 per IP per 10-minute window.

## Deploy with automatic HTTPS

You need:
- A Linux server or VPS with Docker Engine and the Docker Compose plugin installed.
- A domain name you control (for example, `share.example.com`).
- DNS `A` record for that domain pointing to the server's public IPv4 address. If you publish an `AAAA` record, it must point to this server's working IPv6 address; remove an incorrect `AAAA` record.
- Inbound TCP ports **80 and 443** open in the server firewall and hosting-provider firewall. UDP 443 is optional (HTTP/3).

1. Copy the project folder to your server.
2. Create the environment file:
   ```sh
   cp .env.example .env
   ```
3. Edit `.env` and set `DOMAIN` to your real domain. Do not include `https://` or a path.
4. Start the app and HTTPS proxy:
   ```sh
   docker compose up -d --build
   ```
5. Check certificate issuance:
   ```sh
   docker compose logs -f caddy
   ```
6. Open `https://YOUR-DOMAIN` on both Android phones.

Caddy obtains and renews the Let's Encrypt certificate automatically and redirects HTTP to HTTPS. Keep the `caddy_data` Docker volume; it stores certificate and renewal data.

## Run locally for development

```sh
npm install
npm start
```

Open `http://localhost:3000`. For Android phones, deploy with HTTPS: geolocation and screen capture generally require a secure browser context. A phone accessing a LAN IP over plain HTTP will not have the same permissions.

## Important behavior and limitations

- QR connection does not bypass the password or owner approval. The sharer must still approve an unfamiliar device.
- Browser-generated device IDs are convenience identifiers, not verified hardware identities. Clearing site data or changing browsers creates a new ID.
- Location sharing starts only after the device owner presses the location button and grants the browser permission. Speed and heading depend on GPS/device support and may be unavailable or inaccurate.
- The map loads OpenStreetMap tiles from an external provider. That provider may receive the viewer's IP address and requested map area. Location coordinates are decrypted in the browser before being placed on the map.
- SOS is not an emergency-services integration. Do not rely on it for urgent medical, safety, or rescue response.
- Screen capture always requires explicit browser/OS permission and may not be supported consistently by Android browsers. A user can always stop sharing or close the page.
- WebRTC screen media uses DTLS-SRTP. Configure a TURN service for more reliable connections across mobile carrier networks and restrictive Wi-Fi networks.
- Session state, approved devices, and chat history are held only in active browser/server memory and are not persisted. Restarting the server ends sessions.
- The application is a prototype and has not undergone an independent security audit or penetration test. Before public/high-risk use, add a persistent session store, production-grade operational monitoring, stricter origin/CSP policy, dependency review, TURN credentials, abuse controls, and independent security review. Do not use this as a covert tracking tool or sole emergency communication channel.

## Environment and operational notes

- `DOMAIN` in `.env` must be a hostname you control.
- `docker compose up -d --build` rebuilds the Node application and installs the dependencies, including the local QR-code generator.
- `docker compose logs -f app` shows application logs; `docker compose logs -f caddy` shows HTTPS/certificate logs.


## Two-way phone status and calls (added)

After a viewer is approved, either phone can independently choose **Share my phone status**. The other phone receives online/offline state, battery percentage and charging state when the browser exposes the Battery Status API, plus limited connection hints when the Network Information API is available. These APIs are not supported in every Android browser; unavailable values are shown as unavailable. Ordinary web pages cannot read precise Wi-Fi signal strength, cellular signal strength, carrier details, or arbitrary system diagnostics.

The communication panel supports encrypted chat (browser-side AES-GCM), plus peer-to-peer WebRTC voice and video calls. Either side can start a call; the receiving person must tap Accept and grant microphone/camera permission. Calls use WebRTC DTLS-SRTP media encryption. This starter uses a public STUN server; networks with strict NAT/firewalls may require a TURN relay, which is not bundled. Camera/microphone access requires a secure context (HTTPS or localhost).

Status sharing is off until each participant enables it. Calls require explicit acceptance. Stop status sharing, end calls, disconnect, or emergency-stop at any time. The app does not run background phone monitoring after the page is closed.


## Optional project visit and click email alerts

The project can send an email to `subhamsantra08@gmail.com` when a visitor explicitly allows activity notifications, then visits a project page or clicks a button/link. A privacy notice is shown first. Visitors can decline. Alerts contain the event, page, clicked control label, broad device/browser category, and UTC time. They do **not** include IP addresses, precise location, passwords, message contents, or form values. Notifications are rate-limited to 10 per minute per visitor network address; the address is used only for throttling and is not emailed.

Email delivery is **not active until SMTP credentials are configured** on the server. Copy `.env.example` to `.env` (or configure the same environment variables in your hosting provider). For Gmail, use a Google App Password (with 2-Step Verification enabled), not your normal Gmail password:

- `NOTIFY_EMAIL=subhamsantra08@gmail.com`
- `SMTP_HOST=smtp.gmail.com`
- `SMTP_PORT=587`
- `SMTP_SECURE=false`
- `SMTP_USER=the Gmail account used to send notifications`
- `SMTP_PASS=the Gmail App Password`
- `SMTP_FROM=the sending Gmail account`

Install dependencies with `npm install` after adding the new Nodemailer dependency, then restart the server. Keep `.env` private and never upload it to a public repository or share the App Password in chat. For a different email provider, use that provider's SMTP host and settings.
