const express=require("express"),http=require("http"),crypto=require("crypto"),{Server}=require("socket.io"),path=require("path"),nodemailer=require("nodemailer");
const app=express(),server=http.createServer(app),io=new Server(server,{maxHttpBufferSize:1e6}),sessions=new Map(),attempts=new Map(),chars="ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
const IDLE_TTL=15*60*1000,MAX_SESSION_AGE=4*60*60*1000;
app.disable("x-powered-by");
app.use((req,res,next)=>{res.setHeader("X-Content-Type-Options","nosniff");res.setHeader("Referrer-Policy","no-referrer");res.setHeader("Permissions-Policy","camera=(), microphone=(), geolocation=(self), display-capture=(self)");next()});
app.use(express.json({limit:"4kb"}));
app.use(express.static(path.join(__dirname,"public")));
app.get("/vendor/qrcode.js",(_,res)=>res.sendFile(require.resolve("qrcode-generator")));
app.get("/health",(_,r)=>r.json({ok:true}));

// Optional email alerts. Configure SMTP credentials in environment variables; never put them in browser code.
const notifyTo=process.env.NOTIFY_EMAIL||"subhamsantra08@gmail.com";
const mailer=(process.env.SMTP_HOST&&process.env.SMTP_USER&&process.env.SMTP_PASS)
 ? nodemailer.createTransport({host:process.env.SMTP_HOST,port:Number(process.env.SMTP_PORT||587),secure:process.env.SMTP_SECURE==="true",auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASS}})
 : null;
const eventWindows=new Map();
app.post("/api/project-event",async(req,res)=>{
  const {event,page,control,device,browser,consent}=req.body||{};
  if(consent!==true)return res.status(403).json({ok:false});
  if(!["visit","click"].includes(event))return res.status(400).json({ok:false});
  const safePage=typeof page==="string"&&/^\/(?:[a-z0-9._-]+)?$/i.test(page)?page.slice(0,100):"/";
  const safeControl=event==="click"&&typeof control==="string"?control.replace(/[^a-z0-9 _.-]/gi,"").trim().slice(0,60):"";
  const safeDevice=["Android phone","iPhone","Tablet","Desktop","Other"].includes(device)?device:"Other";
  const safeBrowser=["Chrome","Firefox","Safari","Edge","Other"].includes(browser)?browser:"Other";
  // Rate limit notification volume. Client IP is used only for throttling and is never emailed or stored in the message.
  const key=req.ip||"unknown",now=Date.now(),recent=(eventWindows.get(key)||[]).filter(t=>now-t<60000);
  if(recent.length>=10){eventWindows.set(key,recent);return res.status(429).json({ok:false});}
  recent.push(now);eventWindows.set(key,recent);
  if(!mailer)return res.status(503).json({ok:false,reason:"email_not_configured"});
  const when=new Date().toISOString();
  const subject=event==="visit"?"Live Share: project visit":"Live Share: tracked button click";
  const details=[
    "A visitor allowed basic project activity notifications.",
    `Event: ${event}`,
    `Page: ${safePage}`,
    ...(safeControl?[`Button/control: ${safeControl}`]:[]),
    `Device: ${safeDevice}`,
    `Browser: ${safeBrowser}`,
    `Time (UTC): ${when}`,
    "",
    "No passwords, message contents, IP address, precise location, or form values are included."
  ].join("\n");
  try{await mailer.sendMail({from:process.env.SMTP_FROM||process.env.SMTP_USER,to:notifyTo,subject,text:details});res.json({ok:true});}
  catch(err){console.error("Project notification email failed:",err.message);res.status(502).json({ok:false});}
});
const passwordRecord=password=>{const salt=crypto.randomBytes(16);return{salt:salt.toString("hex"),hash:crypto.scryptSync(password,salt,64).toString("hex")}};
const verifyPassword=(password,record)=>{try{const a=crypto.scryptSync(String(password||""),Buffer.from(record.salt,"hex"),64),b=Buffer.from(record.hash,"hex");return a.length===b.length&&crypto.timingSafeEqual(a,b)}catch{return false}};
function code(){let c;do{c=Array.from(crypto.randomBytes(8),b=>chars[b%chars.length]).join("")}while(sessions.has(c));return c}
function list(s){return [...s.approved.values()].map(d=>({id:d.id,label:d.label,connected:!!(s.viewer&&s.viewer.deviceId===d.id)}))}
function devices(s){if(s.sharer)io.to(s.sharer).emit("device-list",list(s))}
function end(c,reason="ended"){let s=sessions.get(c);if(!s)return;[s.sharer,s.viewer,s.pending?.socketId].filter(Boolean).forEach(id=>io.to(id).emit("session-ended",{reason}));sessions.delete(c)}
function active(x){let s=sessions.get(x.data.code);if(s&&[s.sharer,s.viewer].includes(x.id)){s.last=Date.now();return s}return null}
setInterval(()=>{const now=Date.now();for(const [c,s] of sessions){if(now-s.last>IDLE_TTL)end(c,"expired");else if(now-s.createdAt>MAX_SESSION_AGE)end(c,"maximum-duration")}for(const [ip,a] of attempts)if(now-a.t>600000)attempts.delete(ip)},30000).unref();
io.on("connection",x=>{
 x.on("create-session",({password}={},cb)=>{if(typeof password!=="string"||password.length<12||!/[A-Za-z]/.test(password)||!/[0-9]/.test(password))return cb?.({ok:false,error:"Use at least 12 characters, including letters and numbers."});const c=code(),now=Date.now();sessions.set(c,{sharer:x.id,viewer:null,pending:null,approved:new Map(),passwordRecord:passwordRecord(password),createdAt:now,last:now});x.data.code=c;x.data.role="sharer";cb?.({ok:true,code:c,expiresIn:IDLE_TTL})});
 x.on("join-session",({code:c,password,deviceId,label}={},cb)=>{let a=attempts.get(x.handshake.address)||{n:0,t:Date.now()};if(Date.now()-a.t>600000)a={n:0,t:Date.now()};if(++a.n>10){attempts.set(x.handshake.address,a);return cb?.({ok:false,error:"Too many attempts. Try again in 10 minutes."})}attempts.set(x.handshake.address,a);c=String(c||"").toUpperCase().replace(/[^A-Z0-9]/g,"");let s=sessions.get(c);if(!s)return cb?.({ok:false,error:"Invalid or expired session code."});if(s.viewer||s.pending)return cb?.({ok:false,error:"A viewer is already connected or awaiting approval."});if(!verifyPassword(password,s.passwordRecord))return cb?.({ok:false,error:"Incorrect password."});attempts.delete(x.handshake.address);if(typeof deviceId!=="string"||deviceId.length<12)return cb?.({ok:false,error:"Device identifier missing. Reload and retry."});x.data.code=c;x.data.role="viewer";x.data.deviceId=deviceId;s.last=Date.now();if(s.approved.has(deviceId)){s.viewer=x.id;s.approved.get(deviceId).last=Date.now();x.emit("device-approved",{remembered:true});io.to(s.sharer).emit("viewer-connected",{deviceId,label:s.approved.get(deviceId).label});devices(s);cb?.({ok:true,state:"approved"})}else{s.pending={socketId:x.id,deviceId,label:String(label||"Browser").slice(0,80)};io.to(s.sharer).emit("device-request",{deviceId,label:s.pending.label});cb?.({ok:true,state:"pending"})}});
 x.on("approve-device",({deviceId}={})=>{let s=active(x);if(!s||x.data.role!=="sharer"||s.pending?.deviceId!==deviceId)return;let p=s.pending;s.pending=null;s.approved.set(p.deviceId,{id:p.deviceId,label:p.label,last:Date.now()});s.viewer=p.socketId;io.to(s.viewer).emit("device-approved");io.to(s.sharer).emit("viewer-connected",{deviceId:p.deviceId,label:p.label});devices(s)});
 x.on("reject-device",({deviceId}={})=>{let s=active(x);if(!s||x.data.role!=="sharer"||s.pending?.deviceId!==deviceId)return;io.to(s.pending.socketId).emit("device-rejected");s.pending=null});
 x.on("revoke-device",({deviceId}={})=>{let s=active(x);if(!s||x.data.role!=="sharer")return;s.approved.delete(deviceId);if(s.viewer&&io.sockets.sockets.get(s.viewer)?.data.deviceId===deviceId){io.to(s.viewer).emit("session-ended",{reason:"revoked"});let v=io.sockets.sockets.get(s.viewer);if(v){v.data.code=null;v.data.role=null}s.viewer=null}devices(s)});
 x.on("session-heartbeat",()=>{active(x)});
 x.on("encrypted-location",p=>{let s=active(x);if(s&&x.data.role==="sharer"&&s.viewer&&typeof p?.iv==="string"&&typeof p?.data==="string"&&p.data.length<20000)io.to(s.viewer).emit("encrypted-location",p)});
 x.on("viewer-location",p=>{let s=active(x);if(s&&x.data.role==="viewer"&&s.sharer&&typeof p?.iv==="string"&&typeof p?.data==="string"&&p.data.length<20000)io.to(s.sharer).emit("viewer-location",p)});
 x.on("encrypted-chat",p=>{let s=active(x);if(!s||!s.viewer||!s.sharer||typeof p?.iv!=="string"||typeof p?.data!=="string"||p.data.length>12000)return;const target=x.data.role==="sharer"?s.viewer:s.sharer;io.to(target).emit("encrypted-chat",{...p,from:x.data.role})});
 x.on("sos-alert",({message}={})=>{let s=active(x);if(!s||!s.viewer||!s.sharer)return;const target=x.data.role==="sharer"?s.viewer:s.sharer;io.to(target).emit("sos-alert",{from:x.data.role,message:String(message||"Emergency assistance requested").slice(0,180),time:Date.now()})});
 x.on("phone-status",b=>{let s=active(x);if(!s||!s.viewer||!s.sharer||!b||typeof b!=="object")return;const target=x.data.role==="sharer"?s.viewer:s.sharer;io.to(target).emit("phone-status",{online:!!b.online,battery:Number.isFinite(b.battery)?Math.max(0,Math.min(100,Math.round(b.battery))):null,charging:typeof b.charging==="boolean"?b.charging:null,connection:["wifi","cellular","ethernet","unknown"].includes(b.connection)?b.connection:"unknown",effectiveType:String(b.effectiveType||"").slice(0,20),sentAt:Date.now()})});
 x.on("call-control",p=>{let s=active(x);if(!s||!s.viewer||!s.sharer||!['incoming','accepted','rejected','ended'].includes(p?.state)||!['audio','video'].includes(p?.kind||'audio'))return;const target=x.data.role==="sharer"?s.viewer:s.sharer;io.to(target).emit("call-control",{state:p.state,kind:p.kind,from:x.data.role})});
 x.on("call-signal",p=>{let s=active(x);if(s&&s.viewer&&s.sharer&&['offer','answer','ice'].includes(p?.type)){const target=x.data.role==="sharer"?s.viewer:s.sharer;io.to(target).emit("call-signal",p)}});
 x.on("sharing-status",b=>{let s=active(x);if(s&&x.data.role==="sharer"&&s.viewer)io.to(s.viewer).emit("sharing-status",{location:!!b?.location,screen:!!b?.screen})});
 x.on("signal",p=>{let s=active(x);if(s&&s.viewer&&["offer","answer","ice"].includes(p?.type))io.to(x.data.role==="sharer"?s.viewer:s.sharer).emit("signal",p)});
 x.on("end-session",()=>{let c=x.data.code;if(c&&x.data.role==="sharer")end(c);else if(c){let s=sessions.get(c);if(s){if(s.viewer===x.id)s.viewer=null;if(s.pending?.socketId===x.id)s.pending=null;devices(s)}}x.data.code=null;x.data.role=null});
 x.on("disconnect",()=>{let c=x.data.code,s=sessions.get(c);if(!s)return;if(s.sharer===x.id){end(c,"sharer-disconnected");return}if(s.viewer===x.id)s.viewer=null;if(s.pending?.socketId===x.id)s.pending=null;devices(s)});
});
server.listen(process.env.PORT||3000,"0.0.0.0",()=>console.log("Live Share listening"));
